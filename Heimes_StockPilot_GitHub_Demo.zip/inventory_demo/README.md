# StockPilot demonstration
Static browser-based prototype for BCOM 2285. Open index.html locally or publish with GitHub Pages.

Features: dashboard, searchable inventory, keyword-based stock lookup, SKU-based stock changes with confirmation, and low-stock indicators. Sample data persists in browser localStorage.

**Not implemented:** actual AI model, camera barcode scanning, authentication, CSV import, low-stock emails, real inventory integration. Do not claim these are working.

To publish: add index.html to repository root, then GitHub repository Settings → Pages → Deploy from a branch → main / (root) → Save. Wait for the published URL, test in an incognito window.
